class GotoResponse
  include CoresExtensions
  attr_accessor :batch_id, :merchant_id, :first_name, :last_name, :status, :client_id, :order_number, :amount, :sent_date, :transacted_at, :transaction_id, :transaction_type, :auth_code, :description
  def attributes
    at = {}
    self.instance_variables.each do |iv|
      iv.gsub!('@', '')
      at[iv] = self.instance_variable_get("@#{iv}")
    end
    at
  end
  def attributes=(new_attributes)
    return if new_attributes.nil?
    with(new_attributes.dup) do |a|
      a.stringify_keys!
      a.each {|k,v| send(k + "=", a.delete(k)) if self.respond_to?("#{k}=")}
    end
  end
  def transaction
    @transaction ||= GotoTransaction.find_by_batch_id_and_client_id(self.batch_id, self.client_id)
  end
  def initialize(batch_id,attrs={}) # From csv row, or from xml-hash
    new_attrs = {}
    nattrs = attrs.dup
    if nattrs.is_a?(Hash) # Is xml-hash
      nattrs.stringify_keys!
      # status, order_number, transacted_at, transaction_id, description
      new_attrs = nattrs
    elsif nattrs.respond_to?('[]') # Is csv row
      # MerchantID,FirstName,LastName,CustomerID,Amount,SentDate,SettleDate,TransactionID,TransactionType,Status,Description
      new_attrs = {
        :status       => nattrs[9],
        :client_id    => nattrs[3],
        :merchant_id  => nattrs[0],
        :first_name   => nattrs[1],
        :last_name    => nattrs[2],
        :order_number => nattrs[7],
        :term_code    => nil,
        :amount       => nattrs[4],
        :sent_date    => nattrs[5],
        :transacted_at => nattrs[6],
        :transaction_id => nattrs[7],
        :transaction_type => nattrs[8],
        :auth_code    => nil,
        :description  => nattrs[10]
      }
    end
    self.attributes = new_attrs
    self.batch_id = batch_id
  end
  def invalid?
    return 'Status is not a single character' if self.status.length != 1
    return 'Description present on accepted transaction' if self.status == 'G' && !self.description.blank?
    return 'Description blank on declined transaction' if self.status == 'D' && self.description.blank?
    return 'SentDate is not a number' if self.sent_date =~ /\D/
    return 'SettleDate is not a number' if self.transacted_at =~ /\D/
    return false
  end

  def record_to_transaction!
    # self.transaction.transaction_id = self.transaction_id
    if [transaction.description, transaction.status, transaction.sent_date, transaction.transacted_at] != [description, status, sent_date, transacted_at]
      if self.transaction.status == 'G' && self.status == 'D' && self.transaction.transaction_id
        # Was accepted, now declined.
        # Delete the transaction if it was previously created.
        Helios::Transact.update_on_master(self.transaction.transaction_id, :CType => 1, :client_no => self.transaction_id)
        self.transaction.transaction_id = 0
      end
      self.transaction.description = self.description
      self.transaction.status = self.status
      self.transaction.sent_date = self.sent_date
      self.transaction.transacted_at = self.transacted_at
      self.transaction.save
    end
  end
end
